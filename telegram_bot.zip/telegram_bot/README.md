# 🤖 Solana Trading Bot — Guide de déploiement

## Étape 1 — Créer ton bot Telegram

1. Ouvre Telegram → cherche **@BotFather**
2. Envoie `/newbot`
3. Choisis un nom : ex `Solana Trading Assistant`
4. Choisis un username : ex `solana_trading_zMnyy_bot`
5. Copie le **token** qu'il te donne → tu en auras besoin

---

## Étape 2 — Clé API Claude (Anthropic)

1. Va sur **https://console.anthropic.com**
2. Crée un compte ou connecte-toi
3. Va dans **API Keys** → **Create Key**
4. Copie la clé (commence par `sk-ant-...`)

---

## Étape 3 — Déployer sur Railway (gratuit)

### Option A — Via GitHub (recommandée)

1. Crée un compte sur **https://railway.app**
2. Crée un nouveau projet → **Deploy from GitHub**
3. Upload les 4 fichiers : `bot.py`, `requirements.txt`, `Procfile`
4. Dans **Variables** (onglet Variables) ajoute :
   ```
   TELEGRAM_TOKEN = [ton token BotFather]
   ANTHROPIC_API_KEY = [ta clé sk-ant-...]
   AUTHORIZED_USER = zMnyy_
   SOLSCAN_API_KEY = [ta clé Solscan]
   ```
5. Railway démarre automatiquement le bot

### Option B — En local sur ton PC

```bash
# Installer Python 3.11+
pip install -r requirements.txt

# Remplir le fichier .env avec tes vraies clés
nano .env

# Lancer le bot
python bot.py
```

---

## Utilisation du bot

Une fois démarré, sur Telegram :

| Commande | Description |
|---|---|
| `/start` | Démarrer le bot |
| `/reset` | Effacer l'historique |
| `/help` | Aide |

### Exemples de messages :
- `Analyse ce token : NV2RYH954cTJ3ckFUpvfqaQXU4ARqqDH3562nFSpump`
- `Check ce wallet : J7He9MrAMoKKsFiDv8RiKJ3LXrLTYzfGU2zns3ArGxSp`
- `Donne moi 3 coins early stage sous 50M MC avec narrative forte`
- `Fibonacci sur PUNCH`
- `C'est quoi un bundle Jito ?`

---

## Sécurité

- `AUTHORIZED_USER = zMnyy_` → seul ton compte peut utiliser le bot
- Tes clés API ne sont jamais exposées (variables d'environnement)
- Historique limité à 20 messages pour optimiser les coûts

---

## Coûts estimés

- **Railway** : ~$5/mois (ou gratuit avec le plan hobby)
- **Claude API** : ~$0.003 par message → quasi gratuit pour usage personnel
- **Telegram** : 100% gratuit

---

## Support

En cas de problème, envoie le message d'erreur à Claude sur claude.ai 🤝
